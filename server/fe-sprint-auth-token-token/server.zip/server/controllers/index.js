module.exports = {
  login: require('./users/login'),
  logout: require('./users/logout'),
  userInfo: require('./users/userInfo'),
};
