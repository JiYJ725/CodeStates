module.exports = {
  USER_DATA: [
    {
      id: '0',
      userId: 'kimcoding',
      password: '1234',
      email: 'kimcoding@authstates.com',
      name: '김코딩',
      position: 'Frontend Developer',
      location: 'Seoul, South Korea',
      bio: '경제적, 사회적 배경에 상관없이 누구나 잠재력을 발휘할 수 있도록 현장에 필요한 교육을 제공합니다.',
    },
  ],
};
